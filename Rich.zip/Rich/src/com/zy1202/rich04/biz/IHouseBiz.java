package com.zy1202.rich04.biz;

public interface IHouseBiz {
	int upRank();
}
