package com.zy1202.rich04.biz;

import java.util.List;

import com.zy1202.rich04.model.Gift;

public interface IGiftCellBiz {
	void useGift(Gift gift);
}
