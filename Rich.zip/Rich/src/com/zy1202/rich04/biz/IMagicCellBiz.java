package com.zy1202.rich04.biz;

import com.zy1202.rich04.model.Magic;

public interface IMagicCellBiz {
	void useMagic(Magic magic);
}
