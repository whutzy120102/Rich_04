package com.zy1202.rich04.bo;

public interface IHouseBO {
	void setRank(int rank);
	int getRank();
	void setPrice(int price);
	int getPrice();
	int getUpPrice();
}
