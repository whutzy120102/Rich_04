package com.zy1202.rich04.bo;

public interface IPropBo {
	void setName(String name);
	String getName();
	void setIntroduce(String Introduce);
	String getIntroduce();
	void setPoint(int point);
	int getPoint();
}
