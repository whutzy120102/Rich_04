package com.zy1202.rich04.bo;

public interface IMineCellBO {
	void setPoint(int point);
	int getPoint();
}
