package com.zy1202.rich04.bo;

public interface ICellBO {
	void setType(String name);
	String getType();
	void setBombNum(int num);
	int getBombNum();
	void setRoadBlockNum(int num);
	int getRoadBlockNum();
}
