package com.zy1202.rich04.bo;

public interface IMagicBO {
	void setId(int id);
	int getId();
	void setName(String name);
	String getName();
	void setIntroduce(String introduce);
	String getIntroduce();
	
}
